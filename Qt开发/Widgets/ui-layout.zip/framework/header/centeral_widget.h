#ifndef CENTERAL_WIDGET_H
#define CENTERAL_WIDGET_H

#include <QWidget>
#include <QBoxLayout>

#include "navigation_bar.h"

namespace Rose {
    class CenteralWidget : public QWidget {
        Q_OBJECT
    public:
        explicit CenteralWidget(QWidget *parent = nullptr);
        ~CenteralWidget(void);

    private:
        void initLayout(void);
        void initNavigationBar(void);

    private slots:
        void initUi(void);

    private:
        QBoxLayout* m_pMainHLayout;

        NavigationBar* m_pNavigationBar;
        QWidget* m_pChatWidget;

    signals:

    };
}   // namespace Rose

#endif // CENTERALWIDGET_H
