#ifndef CHAT_WIDGET_H
#define CHAT_WIDGET_H

#include <QWidget>
#include <QScrollArea>
#include <QToolBar>
#include <QVBoxLayout>
#include <QHBoxLayout>

#include "chat_message_list.h"
#include "text_edit_area.h"

namespace Rose {
    class ChatWidget : public QWidget {
        Q_OBJECT
    public:
        explicit ChatWidget(QWidget *parent = nullptr);
        ~ChatWidget(void);

    public slots:
        void appendChatMessage(const QString& message);

    signals:

    private:
        void initSignalsAndSlots(void);

    private slots:
        void initUi(void);

    private:
        QVBoxLayout* m_pMainVLayout;
        QScrollArea* m_pChatMessageArea;
        ChatMessageList* m_pChatMessageList;
        QToolBar* m_pChatToolBar;
        TextEditArea* m_pTextEditArea;
        QString m_roleName;
    };
}   // namespace Rose

#endif // CHATWIDGET_H
