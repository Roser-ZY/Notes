#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QHBoxLayout>

#include "centeral_widget.h"

namespace Rose {
    class CustomMainWindow : public QMainWindow {
        Q_OBJECT

    public:
        CustomMainWindow(QWidget *parent = nullptr);
        ~CustomMainWindow(void);

    private:
        CenteralWidget* m_pCenteralWidget;
    };
}   // namespace Rose

#endif // MAINWINDOW_H
