#include "chat_widget.h"

using namespace Rose;

ChatWidget::ChatWidget(QWidget *parent)
    : QWidget{parent}
    , m_pMainVLayout(new QVBoxLayout(this))
    , m_pChatMessageArea(new QScrollArea(this))
    , m_pChatMessageList(new ChatMessageList(m_pChatMessageArea))
    , m_pChatToolBar(new QToolBar(this))
    , m_pTextEditArea(new TextEditArea(this))
    , m_roleName("")
{
    initUi();
    initSignalsAndSlots();
}

ChatWidget::~ChatWidget(void)
{
}

void ChatWidget::initUi(void)
{
    // 初始化控件
    // Initialize widgets.
    m_pChatMessageArea->setWidget(m_pChatMessageList);
    m_pChatMessageArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    m_pChatMessageArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_pChatMessageArea->setWidgetResizable(true);

    // 初始化布局
    // Initialize layouts.
    m_pMainVLayout->addWidget(m_pChatMessageArea);
    m_pMainVLayout->addWidget(m_pChatToolBar);
    m_pMainVLayout->addWidget(m_pTextEditArea);
}

void ChatWidget::initSignalsAndSlots(void)
{
    connect(m_pTextEditArea, SIGNAL(sendButtonClicked(QString)), this, SLOT(appendChatMessage(QString)));
}

// Slots
void ChatWidget::appendChatMessage(const QString& message)
{
    m_pChatMessageList->appendChatMessage(message, m_roleName, Qt::AlignLeft);
}

