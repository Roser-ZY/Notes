#include "centeral_widget.h"

#include <QHBoxLayout>
#include <QVBoxLayout>

#include "chat_widget.h"

using namespace Rose;

CenteralWidget::CenteralWidget(QWidget *parent)
    : QWidget{parent}
    , m_pMainHLayout(new QHBoxLayout(this))
    , m_pNavigationBar(new NavigationBar(this))
    , m_pChatWidget(new ChatWidget(this))
{
    initUi();
}

CenteralWidget::~CenteralWidget(void)
{
}

void CenteralWidget::initUi(void)
{
    initLayout();
    initNavigationBar();
}

void CenteralWidget::initLayout(void)
{
    // 初始化布局
    // Initialize layouts.
    m_pMainHLayout->addWidget(m_pNavigationBar);
    m_pMainHLayout->addWidget(m_pChatWidget);
    m_pMainHLayout->setContentsMargins(0, 0, 0, 0);
    m_pMainHLayout->setSpacing(0);
    // 初始化子控件
    // Initialize children widgets.
    m_pChatWidget->show();
}

void CenteralWidget::initNavigationBar(void)
{
    m_pNavigationBar->addItem(m_pChatWidget, "Chat GPT");
}
