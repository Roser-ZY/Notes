#include "custom_mainwindow.h"

using namespace Rose;

CustomMainWindow::CustomMainWindow(QWidget *parent)
    : QMainWindow(parent)
    , m_pCenteralWidget(new CenteralWidget(this))
{
    resize(800, 600);
    setCentralWidget(m_pCenteralWidget);
}

CustomMainWindow::~CustomMainWindow(void)
{
}
