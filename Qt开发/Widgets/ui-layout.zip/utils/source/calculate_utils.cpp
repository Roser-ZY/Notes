#include "calculate_utils.h"

#include <QFontMetrics>

using namespace Rose;

CalculateUtils::CalculateUtils(void)
{

}

CalculateUtils::~CalculateUtils(void)
{

}

int32_t CalculateUtils::calculateTextSingleLineWidth(const QString& text, const QFont& font)
{
    QFontMetrics fontMetrics(font);
    return fontMetrics.size(Qt::TextSingleLine, text).width();
}

QRect CalculateUtils::calculateTextBoundary(const QString& text, const QFont& font, int32_t maxWidth, int32_t maxHeight)
{
    QFontMetrics fontMetrics(font);
    return fontMetrics.boundingRect(0, 0, maxWidth, maxHeight, Qt::TextWordWrap|Qt::AlignLeft|Qt::AlignVCenter, text);
}
