#ifndef CALCULATE_UTILS_H
#define CALCULATE_UTILS_H

#include <QString>
#include <QFont>

namespace Rose {
    class CalculateUtils {
    public:
        CalculateUtils(void);
        ~CalculateUtils(void);

        static int32_t calculateTextSingleLineWidth(const QString& text, const QFont& font);
        static QRect calculateTextBoundary(const QString& text, const QFont& font, int32_t maxWidth = INT32_MAX, int32_t maxHeight = INT32_MAX);

    private:
        CalculateUtils(CalculateUtils&) = delete;
        CalculateUtils& operator=(CalculateUtils&) = delete;
    };
}   // namespace Rose

#endif // CALCULATE_UTILS_H
