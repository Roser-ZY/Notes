#ifndef LAYOUT_CONVENTION_H
#define LAYOUT_CONVENTION_H

namespace Rose {
    enum class Alignment {
        kLeft = 0,
        kRight
    };
}

#endif // LAYOUT_CONVENTION_H
