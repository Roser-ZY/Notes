#include "chat_message_bubble.h"
#include <algorithm>
#include <QAbstractTextDocumentLayout>
#include <QDebug>
#include "calculate_utils.h"

using namespace Rose;

ChatMessageBubble::ChatMessageBubble(QWidget* parent, const QString& message)
    : QFrame{parent}
    , m_pMainLayout(new QVBoxLayout(this))
    , m_pMessageBrowser(new QTextBrowser(this))
{
    // Initialize self attributes.
    setFrameShape(QFrame::Panel);
    setAutoFillBackground(true);

    // Initialize the message.
    m_pMessageBrowser->setOpenExternalLinks(true);
    m_pMessageBrowser->setMarkdown(message);
    m_pMessageBrowser->setReadOnly(true);

    // Initialize colors.
    configColor();
    QPalette selfPalette = palette();
    selfPalette.setColor(QPalette::Window, m_bubbleColor);
    setPalette(selfPalette);
    m_pMessageBrowser->setTextColor(m_textColor);

    // Initialize the behavior of the bubble.
    m_pMessageBrowser->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_pMessageBrowser->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_pMessageBrowser->setWordWrapMode(QTextOption::WrapAtWordBoundaryOrAnywhere);

    // Initialize layouts.
    m_pMainLayout->addWidget(m_pMessageBrowser);
}

ChatMessageBubble::~ChatMessageBubble(void)
{
}

void ChatMessageBubble::resizeEvent(QResizeEvent* event)
{
    QFrame::resizeEvent(event);
    adjustMessage();
}

void ChatMessageBubble::configColor(void)
{
    m_bubbleColor.setRgb(QRgb(0xF5F5F5));
    m_textColor.setRgb(QRgb(0x212121));
}

// Slots
void ChatMessageBubble::adjustMessage(void)
{
//    QTextDocument* document = m_pMessageBrowser->document();
    qDebug() << width();
//    document->setPageSize(QSizeF(width(), INT32_MAX));
//    document->adjustSize();
//    QSize documentSize = document->size().toSize();
//    m_pMessageBrowser->setFixedSize(documentSize + QSize(5, 5));
//    setFixedSize(m_pMessageBrowser->size() + QSize(m_contentSpace * 2, m_contentSpace * 2));
}
