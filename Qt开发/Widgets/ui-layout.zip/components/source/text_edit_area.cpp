#include "text_edit_area.h"

#include <QString>

using namespace Rose;

TextEditArea::TextEditArea(QWidget* parent)
    : QWidget(parent)
    , m_pMainGridLayout(new QGridLayout(this))
    , m_pTextEdit(new QPlainTextEdit(this))
    , m_pSplitLine(new QFrame(this))
    , m_pTextCounterLabel(new QLabel(this))
    , m_pSendButton(new QPushButton(this))
{
    initUi();
    initSignalsAndSlots();
}

TextEditArea::~TextEditArea(void)
{
}

void TextEditArea::initUi(void)
{
    // 初始化布局
    // Initialize layouts.
    m_pMainGridLayout->addWidget(m_pTextEdit, 0, 0, 2, 5);
    m_pMainGridLayout->addWidget(m_pSplitLine, 3, 0, 1, 5, Qt::AlignVCenter);
    m_pMainGridLayout->addWidget(m_pTextCounterLabel, 4, 0, 1, 2, Qt::AlignLeft | Qt::AlignVCenter);
    m_pMainGridLayout->addWidget(m_pSendButton, 4, 3, 1, 2, Qt::AlignRight | Qt::AlignVCenter);

    // 初始化空间
    // Initialize widgets.
    m_pTextEdit->setPlaceholderText("Ask anything ...");
    m_pSplitLine->setFrameStyle(QFrame::HLine | QFrame::Plain);
    m_pTextCounterLabel->setText("0/1000");
    m_pSendButton->setText("Send");
}


void TextEditArea::initSignalsAndSlots(void)
{
    connect(m_pTextEdit, SIGNAL(textChanged()), this, SLOT(limitTokenNum()));
    connect(m_pTextEdit, SIGNAL(textChanged()), this, SLOT(updateTextCounter()));
    connect(m_pSendButton, SIGNAL(clicked(bool)), this, SLOT(sendMessage()));
}

// Slots
void TextEditArea::limitTokenNum(void)
{
    // TODO
    return;
}

void TextEditArea::updateTextCounter(void)
{
    int32_t textLength = m_pTextEdit->toPlainText().size();
    m_pTextCounterLabel->setText(QString::number(textLength) + "/1000");
}

void TextEditArea::sendMessage(void)
{
    QString messageContent = m_pTextEdit->toPlainText();
    if (messageContent.size() > 0) {
        emit sendButtonClicked(messageContent);
    }
}
