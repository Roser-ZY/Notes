#include "chat_message_item.h"

#include <QPalette>

using namespace Rose;

ChatMessageItem::ChatMessageItem(QWidget* parent, const QString& message, const QString& roleName, const Qt::Alignment alignRule)
    : QWidget{parent}
    , m_alignRule(alignRule)
    , m_pMainHLayout(new QHBoxLayout(this))
    , m_pBubble(new ChatMessageBubble(this, message))
    , m_pProfileLabel(new QLabel(this))
    , m_pProfileIcon(new QIcon())
    , m_roleName(roleName)
{
    initProfile();

    if (m_alignRule & Qt::AlignLeft) {
        m_pMainHLayout->addWidget(m_pProfileLabel);
        m_pMainHLayout->addWidget(m_pBubble);
//        m_pMainHLayout->addStretch();
    }
    else if (m_alignRule & Qt::AlignRight) {
        m_pMainHLayout->addStretch();
        m_pMainHLayout->addWidget(m_pBubble, 0, m_alignRule);
        m_pMainHLayout->addWidget(m_pProfileLabel, 0, m_alignRule);
    }
    else {
        // TODO 报错
        return;
    }
}

ChatMessageItem::~ChatMessageItem(void)
{
}

void ChatMessageItem::initProfile(void)
{
    m_pProfileLabel->setFixedSize(m_profileSize);
    m_pProfileLabel->setText("User");
}
