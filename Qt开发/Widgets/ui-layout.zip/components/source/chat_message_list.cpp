#include "chat_message_list.h"

using namespace Rose;

ChatMessageList::ChatMessageList(QWidget* parent)
    : QWidget(parent)
    , m_pMainVLayout(new QVBoxLayout(this))
{
    m_pMainVLayout->addStretch(1);
}

ChatMessageList::~ChatMessageList(void)
{
}

// Slots
void ChatMessageList::appendChatMessage(const QString& message, const QString& roleName, const Qt::Alignment alignRule)
{
    ChatMessageItem* pItem = new ChatMessageItem(this, message, roleName, alignRule);
    // Update layouts.
    m_pMainVLayout->insertWidget(m_chatMessageItemArray.size(), pItem);
    m_chatMessageItemArray.push_back(pItem);
}
