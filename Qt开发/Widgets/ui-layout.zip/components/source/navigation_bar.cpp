#include "navigation_bar.h"

using namespace Rose;

NavigationBar::NavigationBar(QWidget* pParent)
    : QWidget(pParent)
    , m_pMainVLayout(new QVBoxLayout(this))
    , m_pNavigationItemList(new QListWidget(this))
    , m_pCurrentPageItem(nullptr)
{
    initUi();
    initSignalsAndSlots();
}

NavigationBar::~NavigationBar(void)
{
}

void NavigationBar::addItem(QWidget* pPage, const QString& label)
{
    QListWidgetItem* pItem = new QListWidgetItem(label);
    m_pNavigationItemList->addItem(pItem);
    m_pageMap.insert({pItem, pPage});
}

void NavigationBar::addItem(QWidget* pPage, const QIcon& icon, const QString& label)
{
    QListWidgetItem* pItem = new QListWidgetItem(icon, label);
    m_pNavigationItemList->addItem(pItem);
    m_pageMap.insert({pItem, pPage});
}

void NavigationBar::initUi(void)
{
    // 设置宽度范围
    // Set widgh range.
    setFixedWidth(150);

    m_pMainVLayout->addWidget(m_pNavigationItemList);
}

void NavigationBar::initSignalsAndSlots(void)
{
    connect(m_pNavigationItemList, SIGNAL(itemClicked(QListWidgetItem*)), this, SLOT(showPage(QListWidgetItem*)));
}

// Slots
void NavigationBar::showPage(QListWidgetItem* pClickedItem)
{
    if(m_pageMap.find(m_pCurrentPageItem) != m_pageMap.end()){
        m_pageMap[m_pCurrentPageItem]->hide();
    }
    if(m_pageMap.find(pClickedItem) == m_pageMap.end()){
        // TODO 错误消息
        return;
    }
    m_pageMap[pClickedItem]->show();
    m_pCurrentPageItem = pClickedItem;
}
