#ifndef CHAT_MESSAGE_ITEM_H
#define CHAT_MESSAGE_ITEM_H

#include <QWidget>
#include <QHBoxLayout>
#include <QRect>
#include <QLabel>
#include <QString>
#include <QIcon>
#include <QSize>

#include "chat_message_bubble.h"

namespace Rose {
    class ChatMessageItem : public QWidget {
        Q_OBJECT
    public:
        explicit ChatMessageItem(QWidget *parent = nullptr, const QString& message = "", const QString& roleName = "", const Qt::Alignment alignRule = Qt::AlignLeft);
        ~ChatMessageItem(void);

    private:
        void initProfile(void);

    private:
        Qt::Alignment m_alignRule;
        QHBoxLayout* m_pMainHLayout;
        ChatMessageBubble* m_pBubble;
        QLabel* m_pProfileLabel;
        QIcon* m_pProfileIcon;
        QString m_roleName;

    private:
        const QSize m_profileSize = QSize(15, 15);
    };
}   // namepsace Rose

#endif // CHAT_MESSAGE_ITEM_H
