#ifndef TEXT_EDIT_AREA_H
#define TEXT_EDIT_AREA_H

#include <QWidget>
#include <QPlainTextEdit>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QFrame>

namespace Rose {
    class TextEditArea : public QWidget {
        Q_OBJECT
    public:
        TextEditArea(QWidget* parent = nullptr);
        ~TextEditArea(void);

    signals:
        void sendButtonClicked(const QString&);

    private:
        void initSignalsAndSlots(void);

    private slots:
        void initUi(void);

        void limitTokenNum(void);
        void updateTextCounter(void);

        void sendMessage(void);

    private:
        QGridLayout* m_pMainGridLayout;
        QPlainTextEdit* m_pTextEdit;
        QFrame* m_pSplitLine;
        QLabel* m_pTextCounterLabel;
        QPushButton* m_pSendButton;

    private:
        const int32_t m_maxTokenNum = 1000;
    };
}   // namespace Rose

#endif // TEXT_EDIT_AREA_H
