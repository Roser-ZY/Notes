#ifndef CHAT_MESSAGE_LIST_H
#define CHAT_MESSAGE_LIST_H

#include <vector>

#include <QListWidget>
#include <QVBoxLayout>
#include <QToolBar>
#include <QScrollArea>

#include "chat_message_item.h"
#include "layout_convention.h"

namespace Rose {
    class ChatMessageList : public QWidget {
        Q_OBJECT
    public:
        ChatMessageList(QWidget* parent = nullptr);
        ~ChatMessageList(void);

    public slots:
        void appendChatMessage(const QString& message, const QString& roleName, const Qt::Alignment alignRule);

    private:
        QVBoxLayout* m_pMainVLayout;
        std::vector<ChatMessageItem*> m_chatMessageItemArray;
    };
}   // namespace Rose

#endif // CHAT_MESSAGE_LIST_H
