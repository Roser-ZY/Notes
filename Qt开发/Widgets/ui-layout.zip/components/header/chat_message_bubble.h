#ifndef CHAT_MESSAGE_BUBBLE_H
#define CHAT_MESSAGE_BUBBLE_H

#include <QFrame>
#include <QVBoxLayout>
#include <QTextBrowser>
#include <QColor>
#include <QString>

namespace Rose {
    class ChatMessageBubble : public QFrame {
        Q_OBJECT
    public:
        explicit ChatMessageBubble(QWidget *parent = nullptr, const QString& message = "");
        ~ChatMessageBubble(void);
        void resizeEvent(QResizeEvent* event) override;

    private:
        void configColor(void);

    private slots:
        void adjustMessage(void);

    private:
        QVBoxLayout* m_pMainLayout;
        QTextBrowser* m_pMessageBrowser;
        QColor m_bubbleColor;
        QColor m_textColor;

    private:
        const int32_t m_contentSpace = 10;
        const int32_t m_bubbleMargin = 30;
    };
}   // namespace Rose

#endif // CHAT_MESSAGE_BUBBLE_H
