#ifndef NAVIGATION_BAR_H
#define NAVIGATION_BAR_H

#include <unordered_map>

#include <QWidget>
#include <QListWidget>
#include <QListWidgetItem>
#include <QVBoxLayout>

namespace Rose {
    class NavigationBar : public QWidget {
        Q_OBJECT
    public:
        NavigationBar(QWidget* pParent = nullptr);
        ~NavigationBar(void);

        void addItem(QWidget* pPage, const QString& label);
        void addItem(QWidget* pPage, const QIcon& icon, const QString& label);

    public slots:
        void showPage(QListWidgetItem* pClickedItem);

    private:
        void initSignalsAndSlots(void);

    private slots:
        void initUi(void);

    private:
        QVBoxLayout* m_pMainVLayout;

        QListWidget* m_pNavigationItemList;
        QListWidgetItem* m_pCurrentPageItem;
        std::unordered_map<QListWidgetItem*, QWidget*> m_pageMap;
    };
}   // namespace Rose

#endif // NAVIGATIONBAR_H
